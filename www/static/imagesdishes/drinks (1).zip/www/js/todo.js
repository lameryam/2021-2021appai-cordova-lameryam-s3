const ToDo = function () {

    let _todos = ['Dummy task'];

    const _setLocalStorage = function() {
        console.log('save all tasks as "todo" key in local storage');
        console.log('_todos[]', _todos);
    };

    const _taskList = function() {
        console.log('add all tasks to the ul tag');
    };

    const init = function(){
        console.log('initialize the Todo app');
    };

    const addTask = function(){
        console.log('add a new task');
    };

    const deleteTask = function(id){
        console.log(`delete task with id = ${id}`);
    };

    const editTask = function(id, task){
        console.log(`edit/update a task: _dotos[${id}] = ${task}`);
    };

    return {
        init: init,
        addTask: addTask,
        deleteTask : deleteTask,
        editTask : editTask
    };
}();
