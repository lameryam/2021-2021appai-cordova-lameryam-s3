$(function(){
	document.addEventListener("deviceready", onDeviceReady, false);

	$('#addTask').click(function(){
		console.log('add a new task');
	});

	$('ul').on('blur', '.title', function(){
		console.log('update a task');
	});

	$('ul').on('click', '.deleteTask', function(){
		console.log('delete a task');
	});
});

function onDeviceReady() {
    console.log('Device is ready');
    ToDo.init();
};
